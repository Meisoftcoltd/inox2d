from .inox2d import *

__doc__ = inox2d.__doc__
if hasattr(inox2d, "__all__"):
    __all__ = inox2d.__all__